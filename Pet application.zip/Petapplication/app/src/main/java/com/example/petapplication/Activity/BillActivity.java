package com.example.petapplication.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petapplication.R;
import com.example.petapplication.models.Bill;
import com.example.petapplication.models.Notification;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BillActivity extends AppCompatActivity {

    TextView billCustomer, billCaregiver, billDate, billAmount;
    Button btnShare, btnSendFeedback;
    String billId, viewType;
    Bill currentBill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);

        billCustomer = findViewById(R.id.billCustomer);
        billCaregiver = findViewById(R.id.billCaregiver);
        billDate = findViewById(R.id.billDate);
        billAmount = findViewById(R.id.billAmount);
        btnShare = findViewById(R.id.btnShareBill);
        btnSendFeedback = findViewById(R.id.btnSendFeedbackForm);

        billId = getIntent().getStringExtra("BILL_ID");
        viewType = getIntent().getStringExtra("VIEW_TYPE"); // "CUSTOMER" or "CAREGIVER"

        if (billId != null) {
            loadBillDetails();
        }

        if ("CAREGIVER".equals(viewType)) {
            btnShare.setVisibility(View.GONE);
            btnSendFeedback.setVisibility(View.VISIBLE);
        } else {
            btnShare.setVisibility(View.VISIBLE);
            btnSendFeedback.setVisibility(View.GONE);
        }

        btnShare.setOnClickListener(v -> sendBillNotificationToCaregiver());

        btnSendFeedback.setOnClickListener(v -> sendFeedbackFormToCustomer());
    }

    private void loadBillDetails() {
        FirebaseDatabase.getInstance().getReference("Bills").child(billId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        currentBill = snapshot.getValue(Bill.class);
                        if (currentBill != null) {
                            billCustomer.setText("Customer: " + currentBill.getCustomerName());
                            billCaregiver.setText("Caregiver: " + currentBill.getCaregiverName());
                            billDate.setText("Service Date: " + currentBill.getServiceDate());
                            billAmount.setText("Total Amount: " + currentBill.getTotalAmount() + " LKR");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void sendBillNotificationToCaregiver() {
        if (currentBill == null) return;

        DatabaseReference notifRef = FirebaseDatabase.getInstance().getReference("Notifications").child(currentBill.getCaregiverId());
        String notifId = notifRef.push().getKey();
        
        Notification notification = new Notification(
                notifId,
                currentBill.getPostId(),
                FirebaseAuth.getInstance().getCurrentUser().getUid(),
                currentBill.getCustomerName(),
                currentBill.getCustomerName() + " paid your service"
        );
        notification.setStatus("BILL");
        notification.setBillId(billId);

        notifRef.child(notifId).setValue(notification).addOnSuccessListener(unused -> {
            Toast.makeText(this, "Bill sent to caregiver alert section", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void sendFeedbackFormToCustomer() {
        if (currentBill == null) return;
        
        DatabaseReference notifRef = FirebaseDatabase.getInstance().getReference("Notifications").child(currentBill.getCustomerId());
        String notifId = notifRef.push().getKey();
        
        Notification notification = new Notification(
                notifId,
                currentBill.getPostId(),
                FirebaseAuth.getInstance().getCurrentUser().getUid(),
                currentBill.getCaregiverName(),
                "Feedback form sent"
        );
        notification.setStatus("FEEDBACK_FORM");
        
        notifRef.child(notifId).setValue(notification).addOnSuccessListener(unused -> {
            Toast.makeText(this, "Feedback form sent to customer", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
