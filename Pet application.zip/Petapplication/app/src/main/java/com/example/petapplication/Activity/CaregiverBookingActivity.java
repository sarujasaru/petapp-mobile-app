package com.example.petapplication.Activity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Adapter.JobAdapter;
import com.example.petapplication.R;
import com.example.petapplication.models.post;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CaregiverBookingActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    JobAdapter adapter;
    List<post> bookingList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caregiver_booking);

        recyclerView = findViewById(R.id.caregiverBookingRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        bookingList = new ArrayList<>();
        adapter = new JobAdapter(this, bookingList);
        recyclerView.setAdapter(adapter);

        loadMyBookedJobs();
    }

    private void loadMyBookedJobs() {
        String caregiverId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("Bookings")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        bookingList.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            post p = ds.getValue(post.class);
                            String cgId = ds.child("caregiverId").getValue(String.class);
                            if (p != null && caregiverId.equals(cgId)) {
                                bookingList.add(p);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}
