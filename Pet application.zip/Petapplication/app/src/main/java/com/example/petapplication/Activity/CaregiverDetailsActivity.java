package com.example.petapplication.Activity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petapplication.R;
import com.example.petapplication.models.User;
import com.example.petapplication.models.post;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CaregiverDetailsActivity extends AppCompatActivity {
    TextView cgName, cgPhone, cgEmail, cgLocation;
    Button btnAcceptCG;
    String caregiverId, postId, notifId;
    String caregiverNameStr; // To store name for booking

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caregiver_details);

        caregiverId = getIntent().getStringExtra("CAREGIVER_ID");
        postId = getIntent().getStringExtra("POST_ID");
        notifId = getIntent().getStringExtra("NOTIF_ID");

        cgName = findViewById(R.id.cgName);
        cgPhone = findViewById(R.id.cgPhone);
        cgEmail = findViewById(R.id.cgEmail);
        cgLocation = findViewById(R.id.cgLocation);
        btnAcceptCG = findViewById(R.id.btnAcceptCG);

        loadCaregiverData();

        btnAcceptCG.setOnClickListener(v -> acceptCaregiver());
    }

    private void loadCaregiverData() {
        FirebaseDatabase.getInstance().getReference("users").child(caregiverId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        User user = snapshot.getValue(User.class);
                        if (user != null) {
                            caregiverNameStr = user.getFullname();
                            cgName.setText("Name: " + caregiverNameStr);
                            cgPhone.setText("Phone: " + user.getPhone());
                            cgEmail.setText("Email: " + user.getEmail());
                            cgLocation.setText("Location: " + user.getLocation());
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void acceptCaregiver() {
        DatabaseReference postRef = FirebaseDatabase.getInstance().getReference("Posts").child(postId);
        DatabaseReference bookingRef = FirebaseDatabase.getInstance().getReference("Bookings");

        postRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot postSnapshot) {
                post job = postSnapshot.getValue(post.class);
                if (job != null) {
                    // Add caregiver details to the post object
                    job.setCaregiverId(caregiverId);
                    job.setCaregiverName(caregiverNameStr);
                    job.status = "Confirmed";

                    // Save the updated job object to Bookings node
                    bookingRef.child(postId).setValue(job).addOnSuccessListener(unused -> {
                        // Mark original post as booked so it disappears from AvailableJobs
                        postRef.child("status").setValue("Booked");

                        // Mark notification as accepted
                        FirebaseDatabase.getInstance().getReference("Notifications")
                                .child(job.getUserId())
                                .child(notifId).child("status").setValue("Accepted");

                        Toast.makeText(CaregiverDetailsActivity.this, "Caregiver Accepted! Booking Saved.", Toast.LENGTH_SHORT).show();
                        finish();
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}
