package com.example.petapplication.Activity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Adapter.FeedbackAdapter;
import com.example.petapplication.R;
import com.example.petapplication.models.Feedback;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CaregiverRatingActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    FeedbackAdapter adapter;
    List<Feedback> feedbackList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caregiver_rating);

        recyclerView = findViewById(R.id.ratingRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        feedbackList = new ArrayList<>();
        adapter = new FeedbackAdapter(this, feedbackList);
        recyclerView.setAdapter(adapter);

        loadFeedbacks();
    }

    private void loadFeedbacks() {
        String caregiverId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("Feedbacks").child(caregiverId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        feedbackList.clear();
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            Feedback f = ds.getValue(Feedback.class);
                            if (f != null) {
                                feedbackList.add(f);
                            } 
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}
