package com.example.petapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petapplication.R;
import com.example.petapplication.models.Pet;
import com.example.petapplication.models.post;
import com.example.petapplication.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class CustomerBookingDetailsActivity extends AppCompatActivity {
    TextView detCGName, detCGPhone, detCGEmail, detCGLocation;
    TextView detCatCount, detDogCount, detDuration, detTotalCash;
    Button btnPayNow;
    String postId, caregiverId;
    String customerName, caregiverName, serviceDate, totalPayment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_booking_details);

        postId = getIntent().getStringExtra("POST_ID");
        caregiverId = getIntent().getStringExtra("CAREGIVER_ID");

        detCGName = findViewById(R.id.detCGName);
        detCGPhone = findViewById(R.id.detCGPhone);
        detCGEmail = findViewById(R.id.detCGEmail);
        detCGLocation = findViewById(R.id.detCGLocation);
        detCatCount = findViewById(R.id.detCatCount);
        detDogCount = findViewById(R.id.detDogCount);
        detDuration = findViewById(R.id.detDuration);
        detTotalCash = findViewById(R.id.detTotalCash);
        btnPayNow = findViewById(R.id.btnPayNow);

        loadCustomerName();

        if (caregiverId != null) {
            loadCaregiverInfo();
        }
        if (postId != null) {
            loadBookingCalculation();
        }

        btnPayNow.setOnClickListener(v -> {
            Intent intent = new Intent(CustomerBookingDetailsActivity.this, Payment.class);
            intent.putExtra("CUSTOMER_NAME", customerName);
            intent.putExtra("CAREGIVER_NAME", caregiverName);
            intent.putExtra("SERVICE_DATE", serviceDate);
            intent.putExtra("TOTAL_PAYMENT", totalPayment);
            intent.putExtra("POST_ID", postId);
            intent.putExtra("CAREGIVER_ID", caregiverId);
            startActivity(intent);
        });
    }

    private void loadCustomerName() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            customerName = snapshot.child("fullname").getValue(String.class);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void loadCaregiverInfo() {
        FirebaseDatabase.getInstance().getReference("users").child(caregiverId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        User user = snapshot.getValue(User.class);
                        if (user != null) {
                            caregiverName = user.getFullname();
                            detCGName.setText("Name: " + caregiverName);
                            detCGPhone.setText("Phone: " + user.getPhone());
                            detCGEmail.setText("Email: " + user.getEmail());
                            detCGLocation.setText("Location: " + user.getLocation());
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void loadBookingCalculation() {
        FirebaseDatabase.getInstance().getReference("Bookings").child(postId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        post job = snapshot.getValue(post.class);
                        if (job != null) {
                            serviceDate = job.getDateTime();
                            String daysStr = job.getDays();
                            int daysValue = 1;
                            
                            // Robust numeric extraction
                            if (daysStr != null) {
                                String numericOnly = daysStr.replaceAll("[^0-9]", "");
                                if (!numericOnly.isEmpty()) {
                                    try {
                                        daysValue = Integer.parseInt(numericOnly);
                                    } catch (NumberFormatException e) {
                                        daysValue = 1;
                                    }
                                }
                            }
                            
                            final int finalDays = daysValue;
                            detDuration.setText("Duration: " + finalDays + " Days");

                            if (job.getPets() != null) {
                                final int[] cats = {0};
                                final int[] dogs = {0};
                                final int totalPets = job.getPets().size();
                                final int[] fetchedCount = {0};

                                for (String pid : job.getPets().keySet()) {
                                    FirebaseDatabase.getInstance().getReference("Pets").child(job.getUserId()).child(pid)
                                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot petSnapshot) {
                                                    Pet pet = petSnapshot.getValue(Pet.class);
                                                    if (pet != null) {
                                                        if ("Cat".equalsIgnoreCase(pet.getPetCategory())) cats[0]++;
                                                        else if ("Dog".equalsIgnoreCase(pet.getPetCategory())) dogs[0]++;
                                                    }
                                                    fetchedCount[0]++;
                                                    if (fetchedCount[0] == totalPets) {
                                                        detCatCount.setText("Cats: " + cats[0]);
                                                        detDogCount.setText("Dogs: " + dogs[0]);
                                                        
                                                        // Correct calculation: (Cats * 500 + Dogs * 1000) * total duration days
                                                        double total = (cats[0] * 500.0 + dogs[0] * 1000.0) * finalDays;
                                                        totalPayment = String.format(Locale.US, "%.2f", total);
                                                        detTotalCash.setText("Total Amount: " + totalPayment + " LKR");
                                                    }
                                                }
                                                @Override
                                                public void onCancelled(@NonNull DatabaseError error) {}
                                            });
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}
