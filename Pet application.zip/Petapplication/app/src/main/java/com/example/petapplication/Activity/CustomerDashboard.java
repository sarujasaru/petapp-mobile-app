package com.example.petapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.petapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomerDashboard extends AppCompatActivity {
    private TextView txtWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_customer_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtWelcome = findViewById(R.id.textView10);
        Button btnLogout = findViewById(R.id.button6);
        CardView addpet = findViewById(R.id.cardView1);
        CardView post = findViewById(R.id.cardView2);
        CardView booking = findViewById(R.id.cardView3);
        CardView alert = findViewById(R.id.cardView4);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String uid = currentUser.getUid();
            DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
            usersRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        String nameFromDB = snapshot.child("fullname").getValue(String.class);
                        if (nameFromDB != null) {
                            txtWelcome.setText("Welcome, " + nameFromDB);
                        }
                    }
                }
                @Override
                public void onCancelled(DatabaseError error) {}
            });
        }

        addpet.setOnClickListener(v -> {
            Intent intent = new Intent(CustomerDashboard.this, PetProfile.class);
            startActivity(intent);
        });

        post.setOnClickListener(v -> {
            Intent intent = new Intent(CustomerDashboard.this, jobpost.class);
            startActivity(intent);
        });

        booking.setOnClickListener(v -> {
            // This should open the list of bookings, not the details directly
            Intent intent = new Intent(CustomerDashboard.this, CustomerBookingActivity.class);
            startActivity(intent);
        });

        alert.setOnClickListener(v -> {
            Intent intent = new Intent(CustomerDashboard.this, NotificationActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(CustomerDashboard.this, loginactivity.class);
            startActivity(intent);
            finish();
        });
    }
}
