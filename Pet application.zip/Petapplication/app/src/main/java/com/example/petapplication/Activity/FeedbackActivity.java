package com.example.petapplication.Activity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petapplication.R;
import com.example.petapplication.models.Feedback;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.UUID;

public class FeedbackActivity extends AppCompatActivity {

    RatingBar ratingBar;
    EditText etComment;
    Button btnSubmit;
    String caregiverId, postId, notifId, customerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        ratingBar = findViewById(R.id.ratingBar);
        etComment = findViewById(R.id.etComment);
        btnSubmit = findViewById(R.id.btnSubmitFeedback);

        caregiverId = getIntent().getStringExtra("CAREGIVER_ID");
        postId = getIntent().getStringExtra("POST_ID");
        notifId = getIntent().getStringExtra("NOTIF_ID");

        loadCustomerName();

        btnSubmit.setOnClickListener(v -> submitFeedback());
    }

    private void loadCustomerName() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseDatabase.getInstance().getReference("users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            customerName = snapshot.child("fullname").getValue(String.class);
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void submitFeedback() {
        float rating = ratingBar.getRating();
        String comment = etComment.getText().toString();

        if (rating == 0) {
            Toast.makeText(this, "Please provide a rating", Toast.LENGTH_SHORT).show();
            return;
        }

        String feedbackId = UUID.randomUUID().toString();
        String customerId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        Feedback feedback = new Feedback(
                feedbackId,
                customerId,
                customerName,
                caregiverId,
                String.valueOf(rating),
                comment,
                postId
        );

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Feedbacks").child(caregiverId);
        ref.child(feedbackId).setValue(feedback).addOnSuccessListener(unused -> {
            // Update notification status to indicate it was completed
            FirebaseDatabase.getInstance().getReference("Notifications")
                    .child(customerId).child(notifId).child("status").setValue("COMPLETED");

            Toast.makeText(FeedbackActivity.this, "Feedback submitted successfully!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
