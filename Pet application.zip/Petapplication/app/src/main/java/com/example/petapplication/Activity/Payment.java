package com.example.petapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.petapplication.R;
import com.example.petapplication.models.Bill;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class Payment extends AppCompatActivity {

    TextView txtCustomer, txtCaregiver, txtDate, txtAmount;
    Button btnProceed;
    EditText etCard, etUpi;
    String customerName, caregiverName, serviceDate, totalAmount, postId, caregiverId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        txtCustomer = findViewById(R.id.txtPayCustomer);
        txtCaregiver = findViewById(R.id.txtPayCaregiver);
        txtDate = findViewById(R.id.txtPayDate);
        txtAmount = findViewById(R.id.txtPayAmount);
        btnProceed = findViewById(R.id.btnProceedPay);
        etCard = findViewById(R.id.etCardNumber);
        etUpi = findViewById(R.id.etUpiId);

        customerName = getIntent().getStringExtra("CUSTOMER_NAME");
        caregiverName = getIntent().getStringExtra("CAREGIVER_NAME");
        serviceDate = getIntent().getStringExtra("SERVICE_DATE");
        totalAmount = getIntent().getStringExtra("TOTAL_PAYMENT");
        postId = getIntent().getStringExtra("POST_ID");
        caregiverId = getIntent().getStringExtra("CAREGIVER_ID");

        txtCustomer.setText("Customer Name: " + customerName);
        txtCaregiver.setText("Caregiver Name: " + caregiverName);
        txtDate.setText("Service Date: " + serviceDate);
        txtAmount.setText("Total Payment: " + totalAmount + " LKR");

        btnProceed.setOnClickListener(v -> {
            if (etCard.getText().toString().isEmpty() && etUpi.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please enter payment details", Toast.LENGTH_SHORT).show();
                return;
            }
            generateBill();
        });
    }

    private void generateBill() {
        String billId = UUID.randomUUID().toString();
        String customerId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Bill bill = new Bill(billId, customerId, customerName, caregiverId, caregiverName, serviceDate, totalAmount, postId);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Bills");
        ref.child(billId).setValue(bill).addOnSuccessListener(unused -> {
            Intent intent = new Intent(Payment.this, BillActivity.class);
            intent.putExtra("BILL_ID", billId);
            intent.putExtra("VIEW_TYPE", "CUSTOMER");
            startActivity(intent);
            finish();
        });
    }
}
