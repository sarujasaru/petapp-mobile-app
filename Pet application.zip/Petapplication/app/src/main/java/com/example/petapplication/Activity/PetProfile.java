package com.example.petapplication.Activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Adapter.Petadapter;
import com.example.petapplication.R;
import com.example.petapplication.models.Pet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class PetProfile extends AppCompatActivity {

    // Input fields
    private EditText petName, petBreed, petSex, petAge, searchPet;
    private RadioButton dogRadio, catRadio;
    private Button addPetBtn;

    // RecyclerView
    RecyclerView recyclerView;

    // List & Adapter
    List<Pet> petList;
    Petadapter adapter;

    // Firebase
    FirebaseUser user;
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        androidx.activity.EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pet_profile2);

        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            androidx.core.graphics.Insets systemBars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // UI கூறுகளை இணைத்தல்
        petName = findViewById(R.id.editTextText);
        petBreed = findViewById(R.id.editTextText2);
        petSex = findViewById(R.id.editTextText4);
        petAge = findViewById(R.id.editTextText3);

        // முக்கியம்: searchPet-க்கு XML-ல் தனி ID இல்லை என்பதால் இப்போதைக்கு இதைத் தவிர்க்கிறோம்
        // searchPet = findViewById(R.id.editTextText);

        dogRadio = findViewById(R.id.radioButton3);
        catRadio = findViewById(R.id.radioButton5);
        addPetBtn = findViewById(R.id.button);

        recyclerView = findViewById(R.id.recyclerViewPets);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        petList = new ArrayList<>();

        // Firebase User சரிபார்ப்பு
        user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish(); // பயனர் லாகின் செய்யவில்லை என்றால் பக்கத்தை மூடிவிடவும்
            return;
        }

        uid = user.getUid();

        // Adapter-ஐ முதலில் காலியான லிஸ்ட் மூலம் செட் செய்கிறோம்
        adapter = new Petadapter(this, petList, uid);
        recyclerView.setAdapter(adapter);

        // தரவுகளை லோடு செய்தல்
        loadPets();

        // Add Pet பட்டன் கிளிக்
        addPetBtn.setOnClickListener(v -> addPet());

        // கவனிப்பு: கிராஷ் ஆவதைத் தவிர்க்க முழு Search பகுதியும் நீக்கப்பட்டுள்ளது அல்லது
        // சரியாக கமெண்ட் செய்யப்பட்டுள்ளதா என உறுதி செய்யவும்.
    }

    // ADD PET
    private void addPet() {
        DatabaseReference petRef = FirebaseDatabase.getInstance()
                .getReference("Pets")
                .child(uid);

        String pid = petRef.push().getKey();
        String category = "";

        if (dogRadio.isChecked()) {
            category = "Dog";
        } else if (catRadio.isChecked()) {
            category = "Cat";
        } else {
            Toast.makeText(this, "Select Dog or Cat", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = petName.getText().toString().trim();
        String breed = petBreed.getText().toString().trim();
        String sex = petSex.getText().toString().trim();
        String age = petAge.getText().toString().trim();

        if (name.isEmpty()) {
            petName.setError("Enter name");
            return;
        }

        // Pet object (சரியான வரிசை: pid, petName, petBreed, petAge, petSex, petCategory)
        Pet pet = new Pet(pid, name, breed, age, sex, category);

        if (pid != null) {
            petRef.child(pid).setValue(pet).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(this, "Pet Added Successfully!", Toast.LENGTH_SHORT).show();
                    // பெட்டிகளை காலி செய்தல்
                    petName.setText("");
                    petBreed.setText("");
                    petSex.setText("");
                    petAge.setText("");
                } else {
                    Toast.makeText(this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // LOAD PETS
    private void loadPets() {
        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Pets")
                .child(uid);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                petList.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Pet pet = ds.getValue(Pet.class);
                    if (pet != null) {
                        petList.add(pet);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PetProfile.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}