package com.example.petapplication.Activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.petapplication.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class forgotpassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgotpassword);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve the UID passed from loginactivity
        String userUid = getIntent().getStringExtra("USER_UID");

        EditText newPass = findViewById(R.id.editTextTextPassword1);
        EditText confirmPass = findViewById(R.id.editTextTextPassword);
        Button resetBtn = findViewById(R.id.button5);

        resetBtn.setOnClickListener(v -> {
            String p1 = newPass.getText().toString().trim();
            String p2 = confirmPass.getText().toString().trim();

            if (TextUtils.isEmpty(p1) || TextUtils.isEmpty(p2)) {
                Toast.makeText(this, "Please enter passwords", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!p1.equals(p2)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            if (p1.length() < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(forgotpassword.this);
            builder.setTitle("Confirm Reset");
            builder.setMessage("Are you sure you want to update your password?");

            builder.setPositiveButton("Yes", (dialog, which) -> {
                if (userUid != null) {
                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(userUid);
                    ref.child("password").setValue(p1)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(forgotpassword.this, "Password Updated Successfully!", Toast.LENGTH_LONG).show();
                                finish(); // Go back to login
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(forgotpassword.this, "Update Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                } else {
                    Toast.makeText(this, "User ID not found. Please try again.", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("No", null);
            builder.show();
        });
    }
}
