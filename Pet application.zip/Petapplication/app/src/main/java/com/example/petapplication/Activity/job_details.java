// C:/Users/sasik/AndroidStudioProjects/Petapplication/app/src/main/java/com/example/petapplication/Activity/job_details.java

package com.example.petapplication.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Adapter.Petadapter;
import com.example.petapplication.R;
import com.example.petapplication.models.Notification;
import com.example.petapplication.models.Pet;
import com.example.petapplication.models.post;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class job_details extends AppCompatActivity {
    RecyclerView petRecycler;
    Button btnAccept, btnReject;
    TextView detailLocation, detailDateTime, detailDays;
    String postId, custId;

    Petadapter adapter;
    List<Pet> petList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_details);

        postId = getIntent().getStringExtra("POST_ID");
        custId = getIntent().getStringExtra("CUST_ID");
        boolean viewOnly = getIntent().getBooleanExtra("VIEW_ONLY", false);

        petRecycler = findViewById(R.id.recyclerViewDetails);
        btnAccept = findViewById(R.id.btnAccept);
        btnReject = findViewById(R.id.btnReject);
        detailLocation = findViewById(R.id.detailLocation);
        detailDateTime = findViewById(R.id.detailDateTime);
        detailDays = findViewById(R.id.detailDays);

        if (viewOnly) {
            btnAccept.setVisibility(View.GONE);
            btnReject.setVisibility(View.GONE);
        }

        petList = new ArrayList<>();
        adapter = new Petadapter(this, petList, (String) null);
        petRecycler.setLayoutManager(new LinearLayoutManager(this));
        petRecycler.setAdapter(adapter);

        loadSelectedPets();

        btnAccept.setOnClickListener(v -> sendNotificationToCustomer());
        btnReject.setOnClickListener(v -> finish());
    }

    private void loadSelectedPets() {
        FirebaseDatabase.getInstance().getReference("Bookings").child(postId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            displayJobDetails(snapshot);
                        } else {
                            FirebaseDatabase.getInstance().getReference("Posts").child(postId)
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            displayJobDetails(snapshot);
                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {}
                                    });
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void displayJobDetails(DataSnapshot snapshot) {
        post job = snapshot.getValue(post.class);
        if (job != null) {
            detailLocation.setText("Location: " + snapshot.child("location").getValue(String.class));
            detailDateTime.setText("Date & Time: " + snapshot.child("dateTime").getValue(String.class));
            detailDays.setText("Duration: " + snapshot.child("days").getValue(String.class));

            if (job.getPets() != null) {
                for (String pid : job.getPets().keySet()) {
                    fetchPetInfo(pid);
                }
            }
        }
    }

    private void fetchPetInfo(String pid) {
        FirebaseDatabase.getInstance().getReference("Pets").child(custId).child(pid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Pet pet = snapshot.getValue(Pet.class);
                        if (pet != null) {
                            petList.add(pet);
                            adapter.notifyDataSetChanged();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void sendNotificationToCustomer() {
        String caregiverId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(caregiverId);

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String caregiverName = snapshot.child("fullname").getValue(String.class);
                DatabaseReference notifRef = FirebaseDatabase.getInstance().getReference("Notifications").child(custId);
                String notifId = notifRef.push().getKey();

                Notification notification = new Notification(
                        notifId,
                        postId,
                        caregiverId,
                        caregiverName,
                        caregiverName + " accepted your post"
                );

                notifRef.child(notifId).setValue(notification).addOnSuccessListener(unused -> {
                    Toast.makeText(job_details.this, "Response sent to customer", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}
