package com.example.petapplication.Activity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Adapter.Petadapter;
import com.example.petapplication.R;
import com.example.petapplication.models.Pet;
import com.example.petapplication.models.post;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.widget.Toast;

public class jobpost extends AppCompatActivity {

    EditText location,dateTime, days;
    RecyclerView petRecycler;
    Button createPost;

    List<Pet> petList;
    HashMap<String,Boolean> selectedPets;

    Petadapter adapter;

    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jobpost);
        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser() != null) {
            userId = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser().getUid();
        }

        location=findViewById(R.id.location);
        dateTime=findViewById(R.id.datetime);
        days =findViewById(R.id.days);
        createPost=findViewById(R.id.createPost);
        petRecycler=findViewById(R.id.petRecycler);

        petList=new ArrayList<>();
        selectedPets=new HashMap<>();

        adapter=new Petadapter(this,petList,selectedPets);

        petRecycler.setLayoutManager(new LinearLayoutManager(this));
        petRecycler.setAdapter(adapter);

        loadPets();

        createPost.setOnClickListener(v -> savePost());
    }

    private void loadPets(){

        DatabaseReference ref= FirebaseDatabase.getInstance()
                .getReference("Pets")
                .child(userId);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                petList.clear();

                for(DataSnapshot ds:snapshot.getChildren()){

                    Pet pet=ds.getValue(Pet.class);
                    petList.add(pet);
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void savePost(){

        DatabaseReference ref=FirebaseDatabase.getInstance()
                .getReference("Posts");

        String postId=ref.push().getKey();

        post post=new post(
                postId,
                userId,
                location.getText().toString(),
                dateTime.getText().toString(),
                days.getText().toString(),
                selectedPets
        );

        ref.child(postId).setValue(post);

        Toast.makeText(this,"Post Created",Toast.LENGTH_SHORT).show();
    }
}