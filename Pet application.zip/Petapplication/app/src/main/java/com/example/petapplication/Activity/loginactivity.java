package com.example.petapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.petapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class loginactivity extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin;
    DatabaseReference usersRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_loginactivity);
        
        usersRef = FirebaseDatabase.getInstance().getReference("users");

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEmail = findViewById(R.id.editText2);
        etPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.button);
        TextView signup = findViewById(R.id.button4);
        TextView forgotpassword = findViewById(R.id.textView5);

        signup.setOnClickListener(v -> {
            startActivity(new Intent(loginactivity.this, registeractivity.class));
        });

        forgotpassword.setOnClickListener(v -> {
            String rawEmail = etEmail.getText().toString().trim();
            if (TextUtils.isEmpty(rawEmail)) {
                Toast.makeText(this, "Please enter your email first", Toast.LENGTH_SHORT).show();
                return;
            }

            // Search for user by email field since keys are UIDs
            Query query = usersRef.orderByChild("email").equalTo(rawEmail);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    if (snapshot.exists() && snapshot.hasChildren()) {
                        DataSnapshot userSnap = snapshot.getChildren().iterator().next();
                        String dbEmoji = userSnap.child("security").getValue(String.class);
                        String uid = userSnap.getKey();

                        AlertDialog.Builder builder = new AlertDialog.Builder(loginactivity.this);
                        builder.setTitle("Security Check");
                        builder.setMessage("Enter your favorite emoji to reset password:");

                        final EditText input = new EditText(loginactivity.this);
                        input.setHint("Type emoji here...");
                        builder.setView(input);

                        builder.setPositiveButton("Verify", (dialog, which) -> {
                            String userTypedEmoji = input.getText().toString().trim();
                            if (userTypedEmoji.equals(dbEmoji)) {
                                Intent intent = new Intent(loginactivity.this, forgotpassword.class);
                                intent.putExtra("USER_UID", uid);
                                intent.putExtra("USER_EMAIL", rawEmail);
                                startActivity(intent);
                            } else {
                                Toast.makeText(loginactivity.this, "Wrong Emoji! Access Denied.", Toast.LENGTH_LONG).show();
                            }
                        });
                        builder.setNegativeButton("Cancel", null);
                        builder.show();
                    } else {
                        Toast.makeText(loginactivity.this, "User not found!", Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(DatabaseError error) {}
            });
        });

        btnLogin.setOnClickListener(v -> loginUser());
    }

    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter email & password", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                        usersRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    String role = snapshot.child("role").getValue(String.class);
                                    Intent intent = "Customer".equals(role) ? 
                                            new Intent(loginactivity.this, CustomerDashboard.class) : 
                                            new Intent(loginactivity.this, CaregiverDashboard.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                            @Override
                            public void onCancelled(DatabaseError error) {}
                        });
                    } else {
                        Toast.makeText(loginactivity.this, "Auth Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
