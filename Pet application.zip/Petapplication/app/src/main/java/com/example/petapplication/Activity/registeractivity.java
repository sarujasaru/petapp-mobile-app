package com.example.petapplication.Activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.petapplication.Firebase.FirebaseHelper;
import com.example.petapplication.R;
import com.example.petapplication.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class registeractivity extends AppCompatActivity {


    EditText etFullname, etEmail, etPhone, etPassword, etConfirmPassword, etsecurity;;
    RadioGroup rgRole;
    Spinner spinnerItems;
    CheckBox cbTerms;
    Button btnSignUp;


    FirebaseDatabase database;
    DatabaseReference usersRef;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registeractivity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        etFullname = findViewById(R.id.editText);
        etEmail = findViewById(R.id.editTextEmailAddress);
        etPhone = findViewById(R.id.editTextPhone);
        etPassword = findViewById(R.id.editTextPassword1);
        etConfirmPassword = findViewById(R.id.editTextPassword2);
        rgRole = findViewById(R.id.radioGroup);
        spinnerItems = findViewById(R.id.spinner);
        cbTerms = findViewById(R.id.checkBox);
        btnSignUp = findViewById(R.id.button2);
        etsecurity = findViewById(R.id.textView11);


        // Firebase reference
        database = FirebaseDatabase.getInstance();
        usersRef = database.getReference("users");
        mAuth = FirebaseAuth.getInstance();

        // Spinner setup
        try {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this,
                    R.array.location_types,
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerItems.setAdapter(adapter);
        } catch (Exception e) {
            // Handle case where R.array.location_types might be missing
        }

        // Button click
        btnSignUp.setOnClickListener(view -> registerUser());
    }

    private void registerUser() {
        String fullname = etFullname.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String security = etsecurity.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String item = (spinnerItems.getSelectedItem() != null) ? spinnerItems.getSelectedItem().toString() : "";

        int selectedId = rgRole.getCheckedRadioButtonId();
        RadioButton rb = findViewById(selectedId);
        String role = (rb != null) ? rb.getText().toString() : "";

        // Validation (முக்கியம்: பாஸ்வர்ட் குறைந்தது 6 எழுத்துக்கள் இருக்க வேண்டும்)
        if (TextUtils.isEmpty(fullname) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }


        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Firebase உருவாக்கிய உண்மையான UID
                        String realUid = mAuth.getCurrentUser().getUid();

                        // User Object (இங்கே realUid பயன்படுத்துகிறோம்)
                        User newUser = new User(realUid, fullname, email, phone, password, confirmPassword, role, item, security);

                        // Database-ல் "users" -> "UID" என்று சேமிக்கிறோம்
                        usersRef.child(realUid).setValue(newUser)
                                .addOnCompleteListener(dbTask -> {
                                    if (dbTask.isSuccessful()) {
                                        Toast.makeText(registeractivity.this, "Signup successful!", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }
                                });
                    } else {
                        // இங்கே வரும் பிழையை (Error) கவனியுங்கள்
                        Toast.makeText(registeractivity.this, "Auth Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
    }

