package com.example.petapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Activity.CustomerBookingDetailsActivity;
import com.example.petapplication.Activity.job_details;
import com.example.petapplication.R;
import com.example.petapplication.models.post;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.ViewHolder> {
    Context context;
    List<post> jobList;

    public JobAdapter(Context context, List<post> jobList) {
        this.context = context;
        this.jobList = jobList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.job_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        post job = jobList.get(position);
        holder.location.setText("Location: " + job.location);
        holder.dateTime.setText(job.dateTime);

        if (holder.days != null) {
            holder.days.setText("Duration: " + job.days + " Days");
        }

        String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // If caregiverName exists (Booking section)
        if (job.getCaregiverName() != null && !job.getCaregiverName().isEmpty()) {
            // If the current user is the customer, show the caregiver's name
            if (currentUserId.equals(job.getUserId())) {
                holder.custName.setText("Caregiver: " + job.getCaregiverName());
            } else {
                // If current user is the caregiver, show the customer's name
                fetchCustomerName(job.getUserId(), holder.custName);
            }
        } else {
            // Regular "Available Jobs" view - show customer name
            fetchCustomerName(job.getUserId(), holder.custName);
        }

        holder.btnMore.setOnClickListener(v -> {
            Intent intent;
            // If it's a confirmed booking and the current user is the customer
            if (job.getCaregiverId() != null && currentUserId.equals(job.getUserId())) {
                intent = new Intent(context, CustomerBookingDetailsActivity.class);
                intent.putExtra("POST_ID", job.getPostId());
                intent.putExtra("CAREGIVER_ID", job.getCaregiverId());
            } else {
                // Otherwise (Available Job or Caregiver viewing their booking), show job details
                intent = new Intent(context, job_details.class);
                intent.putExtra("POST_ID", job.getPostId());
                intent.putExtra("CUST_ID", job.getUserId());
                
                // If it's a pending job (caregiverId is null), buttons should be visible (viewOnly = false)
                // If it's a booked job (caregiverId is NOT null), buttons should be hidden (viewOnly = true)
                boolean viewOnly = (job.getCaregiverId() != null);
                intent.putExtra("VIEW_ONLY", viewOnly);
            }
            context.startActivity(intent);
        });
    }

    private void fetchCustomerName(String userId, TextView textView) {
        FirebaseDatabase.getInstance().getReference("users").child(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            textView.setText("Customer: " + snapshot.child("fullname").getValue(String.class));
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    @Override
    public int getItemCount() { return jobList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView custName, location, dateTime, days;
        Button btnMore;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            custName = itemView.findViewById(R.id.jobCustName);
            location = itemView.findViewById(R.id.jobLocation);
            dateTime = itemView.findViewById(R.id.jobDateTime);
            days = itemView.findViewById(R.id.days);
            btnMore = itemView.findViewById(R.id.btnMore);
        }
    }
}
