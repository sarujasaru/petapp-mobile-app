package com.example.petapplication.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.Activity.BillActivity;
import com.example.petapplication.Activity.CaregiverDetailsActivity;
import com.example.petapplication.Activity.FeedbackActivity;
import com.example.petapplication.R;
import com.example.petapplication.models.Notification;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {
    private Context context;
    private List<Notification> notificationList;

    public NotificationAdapter(Context context, List<Notification> notificationList) {
        this.context = context;
        this.notificationList = notificationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.notification_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Notification notification = notificationList.get(position);
        
        holder.notificationTitle.setText(notification.getCaregiverName());
        holder.notificationMessage.setText(notification.getMessage());
        holder.notificationTime.setText(notification.getStatus());

        holder.itemView.setOnClickListener(v -> {
            Intent intent;
            if ("BILL".equals(notification.getStatus())) {
                intent = new Intent(context, BillActivity.class);
                intent.putExtra("BILL_ID", notification.getBillId());
                intent.putExtra("VIEW_TYPE", "CAREGIVER");
            } else if ("FEEDBACK_FORM".equals(notification.getStatus())) {
                intent = new Intent(context, FeedbackActivity.class);
                intent.putExtra("CAREGIVER_ID", notification.getCaregiverId());
                intent.putExtra("POST_ID", notification.getPostId());
                intent.putExtra("NOTIF_ID", notification.getId());
            } else {
                intent = new Intent(context, CaregiverDetailsActivity.class);
                intent.putExtra("CAREGIVER_ID", notification.getCaregiverId());
                intent.putExtra("POST_ID", notification.getPostId());
                intent.putExtra("NOTIF_ID", notification.getId());
            }
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView notificationTitle, notificationMessage, notificationTime;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            notificationTitle = itemView.findViewById(R.id.notificationTitle);
            notificationMessage = itemView.findViewById(R.id.notificationMessage);
            notificationTime = itemView.findViewById(R.id.notificationTime);
        }
    }
}
