package com.example.petapplication.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.R;
import com.example.petapplication.models.Pet;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;

public class Petadapter extends RecyclerView.Adapter<Petadapter.ViewHolder> {

    private Context context;
    private List<Pet> petList;
    private String uid;
    private HashMap<String, Boolean> selectedPets;

    public Petadapter(Context context, List<Pet> petList, String uid) {
        this.context = context;
        this.petList = petList;
        this.uid = uid;
    }

    public Petadapter(Context context, List<Pet> petList, HashMap<String, Boolean> selectedPets) {
        this.context = context;
        this.petList = petList;
        this.selectedPets = selectedPets;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName, txtBreed, txtAge, txtSex, txtCategory;
        Button btnEdit, btnDelete;
        CheckBox checkPet;
        View layoutButtons;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.txtName);
            txtBreed = itemView.findViewById(R.id.txtBreed);
            txtAge = itemView.findViewById(R.id.txtAge);
            txtSex = itemView.findViewById(R.id.txtSex);
            txtCategory = itemView.findViewById(R.id.txtCategory);

            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            checkPet = itemView.findViewById(R.id.checkPet);
            layoutButtons = itemView.findViewById(R.id.layoutButtons);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.pet_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pet pet = petList.get(position);

        if (pet != null) {
            holder.txtName.setText("Name: " + pet.getPetName());
            holder.txtCategory.setText("Category: " + pet.getPetCategory());
            holder.txtBreed.setText("Breed: " + pet.getPetBreed());
            holder.txtAge.setText("Age: " + pet.getPetAge());
            holder.txtSex.setText("Sex: " + pet.getPetSex());

            if (selectedPets != null) {
                // Selection mode
                holder.checkPet.setVisibility(View.VISIBLE);
                holder.layoutButtons.setVisibility(View.GONE);

                holder.checkPet.setOnCheckedChangeListener(null);
                holder.checkPet.setChecked(selectedPets.containsKey(pet.getPid()));

                holder.checkPet.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (isChecked) {
                        selectedPets.put(pet.getPid(), true);
                    } else {
                        selectedPets.remove(pet.getPid());
                    }
                });
            } else {
                // Management mode
                holder.checkPet.setVisibility(View.GONE);

                if (uid != null) {
                    holder.layoutButtons.setVisibility(View.VISIBLE);
                } else {
                    holder.layoutButtons.setVisibility(View.GONE);
                }
            }

            // UPDATE
            holder.btnEdit.setOnClickListener(v -> {
                if (uid == null) return;

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Edit Pet Details");

                LinearLayout layout = new LinearLayout(context);
                layout.setOrientation(LinearLayout.VERTICAL);
                layout.setPadding(40, 20, 40, 20);

                final EditText editName = new EditText(context);
                editName.setHint("Pet Name");
                editName.setText(pet.getPetName());
                layout.addView(editName);

                final EditText editBreed = new EditText(context);
                editBreed.setHint("Pet Breed");
                editBreed.setText(pet.getPetBreed());
                layout.addView(editBreed);

                final EditText editAge = new EditText(context);
                editAge.setHint("Pet Age");
                editAge.setText(pet.getPetAge());
                layout.addView(editAge);

                final EditText editSex = new EditText(context);
                editSex.setHint("Pet Sex");
                editSex.setText(pet.getPetSex());
                layout.addView(editSex);

                builder.setView(layout);

                builder.setPositiveButton("Update", (dialog, which) -> {
                    String newName = editName.getText().toString();
                    String newBreed = editBreed.getText().toString();
                    String newAge = editAge.getText().toString();
                    String newSex = editSex.getText().toString();

                    java.util.Map<String, Object> updateMap = new java.util.HashMap<>();
                    updateMap.put("petName", newName);
                    updateMap.put("petBreed", newBreed);
                    updateMap.put("petAge", newAge);
                    updateMap.put("petSex", newSex);

                    FirebaseDatabase.getInstance()
                            .getReference("Pets")
                            .child(uid)
                            .child(pet.getPid())
                            .updateChildren(updateMap)
                            .addOnSuccessListener(unused ->
                                    Toast.makeText(context, "Pet Updated Successfully!", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(context, "Update Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                });

                builder.setNegativeButton("Cancel", null);
                builder.show();
            });
        }
    }

    @Override
    public int getItemCount() {
        return petList.size();
    }
}
