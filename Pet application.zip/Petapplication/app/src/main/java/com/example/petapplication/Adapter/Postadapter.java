package com.example.petapplication.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petapplication.R;
import com.example.petapplication.models.Pet;

import java.util.HashMap;
import java.util.List;

public class Postadapter extends RecyclerView.Adapter<Postadapter.ViewHolder> {

    private Context context;
    private List<Pet> petList;
    private HashMap<String, Boolean> selectedPets;

    public Postadapter(Context context, List<Pet> petList, HashMap<String, Boolean> selectedPets) {
        this.context = context;
        this.petList = petList;
        this.selectedPets = selectedPets;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView petName;
        CheckBox checkBox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.petName);
            checkBox = itemView.findViewById(R.id.selectPet);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.post_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pet pet = petList.get(position);



        if (pet != null) {
            holder.petName.setText(pet.getPetName());

            // Clear previous listener to avoid bugs during recycling
            holder.checkBox.setOnCheckedChangeListener(null);
            
            // Set checked state based on selection map
            holder.checkBox.setChecked(selectedPets.containsKey(pet.getPid()));

            holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    selectedPets.put(pet.getPid(), true);
                } else {
                    selectedPets.remove(pet.getPid());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return petList.size();
    }
}
