package com.example.petapplication.Firebase;

import android.content.Context;
import android.widget.Toast;

import com.example.petapplication.models.Pet;
import com.example.petapplication.models.User;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseHelper {
    private DatabaseReference usersRef;

    public FirebaseHelper() {
        usersRef = FirebaseDatabase.getInstance().getReference("users");
    }

    public Task<Void> addUser(String emailID, User user) {
        return usersRef.child(emailID).setValue(user);
    }

    public void getUserData(String emailID, ValueEventListener listener) {
        usersRef.child(emailID).addListenerForSingleValueEvent(listener);
    }

    public void verifySecurity(
            String username,
            String answer,
            Context context) {

        DatabaseReference ref =
                FirebaseDatabase.getInstance()
                        .getReference("users");

        ref.child(username).get()
                .addOnSuccessListener(snapshot -> {

                    String dbAns =
                            snapshot.child("security")
                                    .getValue(String.class);

                    if (answer.equals(dbAns)) {

                        Toast.makeText(context,
                                "Correct! Reset allowed",
                                Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(context,
                                "Wrong answer",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void updatePassword(
            String username,
            String newPassword,
            Context context) {

        DatabaseReference ref =
                FirebaseDatabase.getInstance()
                        .getReference("users");

        ref.child(username)
                .child("password")
                .setValue(newPassword)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(context,
                            "Password Updated Successfully!",
                            Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(context,
                            "Update Failed",
                            Toast.LENGTH_SHORT).show();
                });
    }

    public void addPet(String uid, Pet pet) {
        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("Pets")
                .child(uid)
                .child(pet.getPid());

        ref.setValue(pet);
    }
}
