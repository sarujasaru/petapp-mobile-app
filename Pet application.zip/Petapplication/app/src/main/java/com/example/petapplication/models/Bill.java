package com.example.petapplication.models;

public class Bill {
    private String billId;
    private String customerId;
    private String customerName;
    private String caregiverId;
    private String caregiverName;
    private String serviceDate;
    private String totalAmount;
    private String postId;

    public Bill() {}

    public Bill(String billId, String customerId, String customerName, String caregiverId, String caregiverName, String serviceDate, String totalAmount, String postId) {
        this.billId = billId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.caregiverId = caregiverId;
        this.caregiverName = caregiverName;
        this.serviceDate = serviceDate;
        this.totalAmount = totalAmount;
        this.postId = postId;
    }

    public String getBillId() { return billId; }
    public String getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
    public String getCaregiverId() { return caregiverId; }
    public String getCaregiverName() { return caregiverName; }
    public String getServiceDate() { return serviceDate; }
    public String getTotalAmount() { return totalAmount; }
    public String getPostId() { return postId; }
}
