package com.example.petapplication.models;

public class Feedback {
    private String feedbackId;
    private String customerId;
    private String customerName;
    private String caregiverId;
    private String rating; // e.g., "5"
    private String comment;
    private String postId;

    public Feedback() {}

    public Feedback(String feedbackId, String customerId, String customerName, String caregiverId, String rating, String comment, String postId) {
        this.feedbackId = feedbackId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.caregiverId = caregiverId;
        this.rating = rating;
        this.comment = comment;
        this.postId = postId;
    }

    public String getFeedbackId() { return feedbackId; }
    public String getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
    public String getCaregiverId() { return caregiverId; }
    public String getRating() { return rating; }
    public String getComment() { return comment; }
    public String getPostId() { return postId; }
}
