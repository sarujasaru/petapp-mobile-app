package com.example.petapplication.models;

public class Notification {
    private String id;
    private String postId;
    private String caregiverId;
    private String caregiverName;
    private String message;
    private String status; // "Pending", "Accepted", "BILL", "FEEDBACK_FORM"
    private String billId;

    public Notification() {}

    public Notification(String id, String postId, String caregiverId, String caregiverName, String message) {
        this.id = id;
        this.postId = postId;
        this.caregiverId = caregiverId;
        this.caregiverName = caregiverName;
        this.message = message;
        this.status = "Pending";
    }

    public String getId() { return id; }
    public String getPostId() { return postId; }
    public String getCaregiverId() { return caregiverId; }
    public String getCaregiverName() { return caregiverName; }
    public String getMessage() { return message; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getBillId() { return billId; }
    public void setBillId(String billId) { this.billId = billId; }
}
