package com.example.petapplication.models;

public class Pet {
private String pid;
private String petName;
private String petBreed;
private String petAge;
private String petSex;
private String petCategory;

    public Pet(){

    }
public Pet(String pid, String petName, String petBreed, String petAge, String petSex, String petCategory){
        this.pid = pid;
        this.petName = petName;
        this.petBreed = petBreed;
        this.petAge = petAge;
        this.petSex = petSex;
        this.petCategory = petCategory;


}
// Getters and setters
    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

    public String getPetAge() {
        return petAge;
    }

    public void setPetAge(String petAge) {
        this.petAge = petAge;
    }

    public String getPetSex() {
        return petSex;
    }

    public void setPetSex(String petSex) {
        this.petSex = petSex;
    }

    public String getPetCategory() {
        return petCategory;
    }

    public void setPetCategory(String petCategory) {
        this.petCategory = petCategory;
    }

} // Final closing brace