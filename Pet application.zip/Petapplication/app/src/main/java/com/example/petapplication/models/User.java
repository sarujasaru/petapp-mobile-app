package com.example.petapplication.models;

public class User {

    private String uid;
    private String fullname;
    private String email;
    private String phone;
    private String password;
    private String confirmPassword;
    private String role;

    private String location;
    private String security;



    public User(){

    }


    public User(String uid, String fullname, String email, String phone, String password, String confirmPassword, String role, String location, String security) {
        this.uid = uid;
        this.fullname = fullname;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.role = role;
        this.location = location;
        this.security = security;
    }

    // Getters and setters for the fields

    public String getFullname() {
        return fullname;
    }
    public String getEmail() {
        return email;
    }
    public String getPhone(){
        return phone;

    }

    public String getPassword() {
        return password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public String getRole() {
        return role;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSecurity() {
        return security;
    }
    public void setSecurity(String security) {
        this.security = security;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

}
