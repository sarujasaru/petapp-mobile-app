package com.example.petapplication.models;
import java.util.HashMap;

public class post {

    public String postId;
    public String userId;
    public String location;
    public String dateTime;
    public String days;
    public String status;
    public String caregiverId;
    public String caregiverName;

    public HashMap<String,Boolean> pets;

    public post(){}

    public post(String postId,String userId,String location,String dateTime,String days,HashMap<String,Boolean> pets){
        this.postId = postId;
        this.userId = userId;
        this.location = location;
        this.dateTime = dateTime;
        this.days = days;
        this.pets = pets;
        this.status = "Pending";
    }
    public String getPostId() { return postId; }
    public String getUserId() { return userId; }
    public String getLocation() { return location; }
    public String getDateTime() { return dateTime; }
    public String getDays() { return days; }
    public String getStatus() { return status; }
    public HashMap<String, Boolean> getPets() { return pets; }
    public String getCaregiverId() { return caregiverId; }
    public void setCaregiverId(String caregiverId) { this.caregiverId = caregiverId; }
    public String getCaregiverName() { return caregiverName; }
    public void setCaregiverName(String caregiverName) { this.caregiverName = caregiverName; }
}
